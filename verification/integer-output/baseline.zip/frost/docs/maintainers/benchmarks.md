# Benchmarking Frost

Benchmarks are optimized executables with calibrated batches and retained raw
samples. They assert observable answers before timing. They are evidence for
the stated inputs on the measured host, not pass/fail correctness gates.

```sh
cargo bench --locked --all-features --bench ordered_sets
cargo bench --locked --all-features --bench adaptive_maps
cargo bench --locked --all-features --bench snapshots
cargo bench --locked --all-features --bench set_operations
cargo bench --locked --all-features --bench performance_review
cargo bench --locked --features int-set --bench integer_sets
```

`ordered_sets` covers ratio boundaries, balanced input, prefix/tail clusters,
distributed members, and mixed distributions through count and iterator paths.
`adaptive_maps` distinguishes construction from drain and extension work and
shows explicit policy thresholds. `snapshots` compares owned and guarded reads
with persistent synchronized workers. `set_operations` uses native set controls;
`performance_review` preserves the earlier 140-case corpus.
`integer_sets` compares fixed integer representations, all four materialized
operations, mixed intersections, and construction on identical logical inputs.
It includes dense local windows, long runs, scattered upper prefixes, signed
values, and application IDs. Its current construction inputs are sorted;
those cases do not measure shuffled-ingest sorting throughput.

## Measurement contract

Record Rust, target, OS, CPU, affinity, Cargo profile, RUSTFLAGS, and dependency
lockfile. Use the same harness and flags for both implementations. For a
comparison, run before/after/after/before serially, without concurrent builds or
other benchmarks. On Linux, `taskset -c 0` can pin single-threaded comparisons;
do not pin all contending-reader workers to one CPU when measuring multicore
contention. Include thread counts and affinity for that workload separately.

Validate cardinalities and checksums before timing. Consume results through
`black_box`. State whether setup, allocation, destruction, and thread startup
are included. For mutation benchmarks, restoring input is setup; destroying a
returned result is part of the cost only when the stated operation includes it.
Thread startup and join overhead must not masquerade as snapshot read cost.

Use the standard collection's native operation as the primary control. A
naive scan may explain an algorithmic difference but cannot stand in for native
intersection. Count actual lookups rather than labeling every row by a fixed
number when a short collection supplies fewer keys. Assert that miss probes
really miss. Do not infer allocated bytes from capacity without accounting for
the backend's buckets, control bytes, alignment, and allocator.

Keep individual samples, median/min/max, baseline regressions, and input shapes.
Noise, inlining and code layout affect nanosecond cases; repeated measurements
help assess them but do not establish cross-platform superiority. Do not add
wall-clock speed assertions to CI. Comparison-count bounds belong in regression
tests when they express the intended algorithmic complexity.

Historical results and their environment are under `verification/history/` and
[the previous review](../reviews/performance-review.md). The prior production
candidate's results are under `verification/results/`; integer-profile results
are under `verification/int-set/`. [Current validation](../integer-validation.md)
states which runs were actually completed for this revision.
