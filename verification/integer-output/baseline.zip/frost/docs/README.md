# Frost documentation

Start with the [crate README](../README.md) for API examples and features.

| Document | Purpose |
| --- | --- |
| [Design philosophy](design/philosophy.md) | Durable principles and review criteria |
| [Architecture](design/architecture.md) | Families, capabilities, profiles, and backend boundaries |
| [Design decisions](design/decisions.md) | Why the original architecture was selected |
| [Snapshot publication](design/snapshots.md) | Ownership, identity, retries, and linearization |
| [Typed integer profile](design/integer-sets.md) | Canonical key codecs, private storage, policies, and encoded algebra |
| [Integer adversarial review](reviews/integer-design-audit.md) | Design risks, corrections, and scope decisions |
| [Integer validation](integer-validation.md) | Current implementation, test, and benchmark evidence |
| [Integer benchmarks](integer-benchmarks.md) | Measured representation tradeoffs and the mixed-probe improvement |
| [Set operations](set-operations.md) | Algebra, representatives, complexity, and bitmap universes |
| [Maintainer guide](maintainers/guide.md) | Code map, invariants, and change-specific checks |
| [Benchmarks](maintainers/benchmarks.md) | Fair measurement and reproduction |
| [Verification](verification.md) | Executable models, proof bounds, and limitations |
| [Release procedure](maintainers/releasing.md) | Concrete gates before publishing |
| [Integration review](reviews/incoming-assessment.md) | Disposition of the attached patch and review claims |
| [Prior integration validation](production-readiness.md) | Historical checks before the integer profile was added |
| [Previous performance review](reviews/performance-review.md) | Earlier kernel improvements and raw evidence |

Historical review and verification documents under `reviews/` preserve earlier
findings. The original attached review and patch under `reviews/supplied/` are
unmodified evidence; their claims are not automatically current project policy.
