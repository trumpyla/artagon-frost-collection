# Frozen integer profile

`FrozenIntSet<K>` is an explicit integer-domain profile. The key type chooses a
canonical unsigned encoding at compile time. Construction chooses one of a
fixed set of private representations from the observed codes. Algebra dispatches
on the operand representations and keeps its inner work on encoded values.

Enable `int-set` to obtain the complete profile. This feature includes the
existing `roaring-0_12` integration and requires std; it does not add variants to
an already available alloc-only type. The ordinary `MutableOrderedSet::freeze()`
pairing remains `FrozenOrderedSet`. No new mutable integer family or fictitious
mutable wrapper is introduced.

## Public type and encoding contracts

```rust
pub trait IntKey: Copy + Ord {
    type Word: IntWord;
    fn encode(self) -> Self::Word;
    fn decode(word: Self::Word) -> Option<Self>;
}
```

`IntWord` is sealed to u32 and u64. Its private storage supertrait associates
each width with its backend and iterator implementations. A narrow documented
`private_bounds` allowance marks this sealing boundary. Applications implement
the safe `IntKey` trait and select a primitive word; they do not implement
backend machinery or name private representation types.

Names follow the existing crate vocabulary: `FrozenIntSet` names the immutable
profile, `IntKey` names the logical codec, and `IntWord` names its supported
primitive storage width. `IntSetPolicy` is the explicit construction choice;
`IntSetBackend` describes the requested candidate and `IntSetRepr` reports the
observed representation. Backend implementations remain private. These names
avoid exposing a second generic parameter or inventing a mutable family for an
input staging vector.

| Logical type | Word | Encoding |
| --- | --- | --- |
| u32 | u32 | Identity |
| i32 | u32 | Same-width bit pattern XOR `1 << 31` |
| u64 | u64 | Identity |
| i64 | u64 | Same-width bit pattern XOR `1 << 63` |
| NonZeroU32 / NonZeroU64 | Corresponding unsigned word | Extract value; checked nonzero decoding |
| Application newtype | Associated u32 or u64 | Application-defined canonical codec |

The signed mapping is a bijection that preserves numerical ordering. It maps
the signed minimum to zero, negative one immediately below the sign-bit boundary,
zero to that boundary, and the signed maximum to the unsigned maximum. It
changes ordering coordinates; it does not by itself compress anything.

An application can preserve its domain in signatures:

```rust
use frost::integer::{FrozenIntSet, IntKey};

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
struct UserId(u64);

impl IntKey for UserId {
    type Word = u64;
    fn encode(self) -> u64 { self.0 }
    fn decode(word: u64) -> Option<Self> { Some(Self(word)) }
}

let users: FrozenIntSet<UserId> = [UserId(9), UserId(2)].into_iter().collect();
assert_eq!(users.iter().collect::<Vec<_>>(), [UserId(2), UserId(9)]);
```

Binary methods require the same K. UserId and OrderId are not interchangeable
because both use u64. Encoding uses value conversions, so `repr(transparent)`
is unnecessary. A `PhantomData<K>` preserves the key's lifetime and auto-trait
restrictions despite storing only unsigned words; there are no unsafe Send/Sync
implementations.

### Laws and checks

The codec must reconstruct the complete original value, preserve order, accept
only canonical codes, and remain stable across calls, threads, and collections.
A decoder that accepts a word must re-encode it to that exact word. Per-set
offsets belong in storage, never in the global codec.

Checked construction validates observed encode/decode round trips, canonicality,
and adjacent order after normalizing codes. This is not a proof of arbitrary
downstream code. In particular, equality that ignores metadata cannot detect
that encoding discarded that metadata. A codec can also behave differently for
unseen values or after global state changes. Use ordinary frozen sets to retain
stored representatives with additional data.

`IntKey` remains safe: violated laws may produce a returned error, a checked
panic, or wrong logical answers, but never justify unchecked memory access or
constructing invalid Rust values. User callback panics propagate. Iteration
uses checked decoding and can panic when a previously valid code stops decoding.

## Construction, membership, and capabilities

`try_from_iter(input, policy)` consumes keys, validates, sorts and deduplicates
their words, then selects storage. `try_from_encoded(words, policy)` validates
logical words before they enter storage. It is not unchecked backend
deserialization. `FromIterator` uses automatic construction and panics on an
observed invalid codec; callers requiring a returned error use the checked API.

`IntSetPolicy` also implements an explicit fallible freeze plan for supported
owned sources. `Vec<K>`, `MutableOrderedSet<K>`, and `FrozenOrderedSet<K>` can use
`try_freeze_with(policy)`. An ordinary returned rejection retains that source.
Allocation failure and user-code panics follow Rust's normal behavior and are
not advertised as transactional errors.

```rust
use frost::{TryFreezeWith, integer::IntSetPolicy};
let integers = vec![-4_i64, 2, -4, 0]
    .try_freeze_with(IntSetPolicy::auto())
    .unwrap();
assert_eq!(integers.iter().collect::<Vec<_>>(), [-4, 0, 2]);
```

`contains(&K)` encodes the query once. `iter()` reconstructs K by value;
compressed storage cannot lend a stored `&K`. `encoded_values()` provides typed
canonical words without revealing a backend object. The profile implements
`ValueElements`, `SetContains`, and `Cardinality`, with `try_len()` for explicit
conversion to usize. It deliberately does not implement the address-sized `Len`
trait or promise `ExactSizeIterator` for every cardinality.

Counts are u64. Inclusive encoded spans are u128, because the inclusive span
from zero to u64::MAX is 2^64. Set cardinality itself remains limited to u64::MAX;
count arithmetic checks true overflow rather than overflowing before subtracting
overlap. Cardinality and encoded bounds have fast storage queries; `statistics()`
explicitly scans the codes to report runs and upper-32-bit partitions.

## Fixed representation candidates and planning

| Word | Sorted | Dense | Roaring |
| --- | --- | --- | --- |
| u32 | Ascending boxed u32 codes | Aligned local window of u64 bitmap words | RoaringBitmap |
| u64 | Ascending boxed u64 codes | Aligned local window of u64 bitmap words | RoaringTreemap |

The planner provides `auto`, `sorted`, `dense`, and `roaring` policies. Auto is
a deterministic memory-oriented heuristic, not a learned or proven speed
selector. Explicit selections make benchmark and application decisions
reviewable. The default limits are 8 MiB of dense payload and 4,096 distinct
upper-32-bit Roaring partitions. Builders can change those limits explicitly.

Dense payload is computed from the actual aligned window with wide arithmetic
before allocating. Its byte limit is a hard payload bound. Roaring's partition
cap prevents a scattered u64 input from silently creating a very large number
of tiny child bitmaps. Its storage estimate is a planning proxy, not an allocator
measurement or an upper bound on resident memory. Serialized byte counts would
also fail to establish that bound. Input staging, sorting, candidate construction,
allocator overhead, and overall process memory are outside the dense budget.

The current planner's score is explicit: sorted payload plus 16 bytes; dense
payload plus 24 bytes; and, for Roaring, 32 bytes globally plus a score for each
16-bit container of `32 + min(2*members, 8192, 4*runs + 2)`. The u64 candidate
adds 80 bytes per upper-32-bit partition. These constants are transparent
estimates rather than allocator measurements. Equal scores retain
the earlier sorted/dense candidate. Explicit sorted/dense policies avoid the
Roaring statistics pass; explicit Roaring checks its partition cap. The dense
payload must also fit the target's allocation-size bound before allocation.

The basic payload estimates `4*n`, `8*n`, and `8*ceil(W/64)` explain why local
windows help. The often-quoted 3.125%/1.5625% break-even densities ignore headers,
rounding, alignment and construction costs; they are not throughput thresholds.

### Coordinate alignment

Dense storage aligns its encoded base down to a multiple of 64. Equal vector
indices from two different bases are not equal logical coordinates. Pair kernels
align absolute block numbers before combining words. Alignment can add one word
relative to a window starting exactly at its minimum, but avoids a shifting
interpretation at every pair operation.

For example, one window containing encoded 1 and another containing encoded 65
both have bit one set in their first word. Their bases are 0 and 64 respectively;
ANDing those first words without their bases would invent a shared member.
Tests therefore vary bases, boundary positions,
signed zero crossings, and values near unsigned maximums.

## Algebra and output selection

Union, intersection, difference, and symmetric difference only select existing
input codes. Valid restricted domains therefore remain valid. No range-fill or
unbounded complement API invents codes in enum gaps or nonzero domains. A
complement relative to an explicit valid universe is `universe.difference(&set)`.

Same-backend Roaring pairs use native operations, dense pairs use aligned word
kernels, and sorted pairs use encoded algorithms. Mixed pairs use encoded
membership or traversal. Scalar counts and materialized algebra do not call the
logical codec for every member. Decoding happens when a caller requests values.

For sorted/compressed intersection and disjointness, direction accounts for the
cost of binary-searching sorted storage. With n sorted members and m compressed
members, scan sorted when `n <= m * bit_width(n) + scan_words`, using u128 for
the comparison. `scan_words` is the dense buffer length or zero for Roaring.
This retains compressed-side probing for extreme cardinality skew while avoiding
thousands of binary searches on balanced inputs. Dense/Roaring pairs still probe
the smaller member count. This is a work estimate, not a CPU-cost proof; Roaring
partition/container lookup costs and cache behavior can change the preference.

The output representation follows the pair kernel; an input's construction plan
is not a permanent result budget. Native Roaring kernels retain Roaring results;
mixed and sorted paths return sorted codes. Identity fast paths can return the
canonical empty sorted set. Dense pair results trim empty edge
words and retain dense storage when their payload fits the maximum of 8 MiB and
the two input payload sizes; a wider union/XOR falls back to sorted merging.
This operation cap is a growth guard, not the original constructor's limit.
`with_policy(policy)` explicitly rebuilds a result when a particular representation
is required. It uses an O(n) staging vector and is not a free view conversion. Mixed operations
can require O(n) traversal and output space; the profile does not claim that all
representation pairs match native same-backend throughput.

Equality, ordering and hashing are representation-independent over canonical
ascending words. The key law is what makes these operations correspond to the
logical domain. Cloning clones storage; this profile does not promise cheap
shared ownership. A separately named shared profile would need its own contract.

## SIMD and deferred additions

The pinned Roaring 0.12.0 source uses fearless_simd, with its std feature enabling
runtime instruction selection on x86/x86-64 for supported operations. Frost
delegates those kernels rather than adding a second unsafe dispatch layer.
The [upstream README](https://github.com/RoaringBitmap/roaring-rs) documents that
behavior. This does not mean every operation or storage pair uses SIMD.

`std::simd` is not enabled on Frost's stable compiler. The actual Rust 1.99.1
[compile probe](../../verification/int-set/portable-simd-probe.log) rejected it
with E0658; the [standard-library documentation](https://doc.rust-lang.org/stable/std/simd/)
also marks portable SIMD experimental. Fresh sorted SIMD kernels require
independent correctness, CPU-dispatch and fallback tests plus measurements.

Offset-narrowed u64 storage, C-backed CRoaring, alternate codecs, extra block-size
parameters, rank/select APIs, serializers, and a mutable integer family are
deferred. They are not needed to establish this profile's width, codec, planning,
and mixed-algebra contracts. See the [adversarial review](../reviews/integer-design-audit.md)
for the decisions and [the current validation report](../integer-validation.md)
for executed evidence.
