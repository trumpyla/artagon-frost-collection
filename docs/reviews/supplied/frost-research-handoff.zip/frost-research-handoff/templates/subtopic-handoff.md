# Focused Frost research handoff

```yaml
question_id: REPLACE
parent_report_id: REPLACE
parent_path: REAL_PATH
parent_revision: REPLACE
parent_sections_or_claims: []
child_report_id: REPLACE
mode: deep-dive
output_path: REAL_PATH
```

## Decision to unlock
A single concrete architectural/API/algorithm decision, and why the parent overview cannot settle it.

## Known evidence and assumptions to revalidate
List confirmed findings separately from working assumptions. Link sources/claims, not just the parent title. Identify stale version or implementation claims.

## Scope and exclusions
Specify the logical domain, output contract, supported environments and workloads. Define adjacent topics that should not absorb this investigation.

## Competing hypotheses or designs
Include the status quo/simple implementation. For each alternative, state the strongest reason to select it and a plausible failure condition.

## Questions to answer
Define laws, invariant boundaries, ownership, observable semantics, CPU/memory/I/O costs, failure cases and integration constraints. Avoid a generic request to “research deeply.”

## Required evidence and experiments
Name primary specifications/papers/source areas, differential oracles, counterexamples and reproducible benchmarks. Mark experimental work conditional on actual tool availability; no fictional runs.

## Acceptance criteria
Specify what a maintainer needs to choose an alternative. A negative result or a clearly bounded unknown is acceptable; unqualified speculation is not.

## Deliverables and feedback
One standalone report, an evidence ledger, proposed design changes, test/benchmark plans or actual results, and a concise update to the parent's claim/decision matrix. A child report does not automatically approve an ADR or implementation task.
