# Frost research prompt

## Parameters

```yaml
mode: landscape # landscape | deep-dive | validation
research_id: REPLACE
question: REPLACE
engineering_decision: REPLACE
repo: trumpyla/artagon-frost-collection
repo_revision: INSPECT_AND_RECORD
execution_date: ACTUAL_DATE
parent_report: NONE_OR_REAL_PATH_AND_ID
parent_sections_and_claims: []
output_path: REAL_REPOSITORY_RELATIVE_PATH
scope: []
non_goals: []
constraints: []
workload_model: REPLACE
resource_budgets: REPLACE_OR_UNKNOWN
```

## Role and goal

Act as a Rust systems researcher and algebra/verification engineer. Answer the specified question so a maintainer can make the engineering decision. Produce the requested report file, not merely a plan or a list of libraries. Read the repository's current instructions, architecture, relevant code, tests, and parent research first. State what you could not inspect.

## Fixed project context to verify against the checkout

The user's target layout is flat `crates/frost-*`, with `frost-api` as public facade and Rust import name `frost`. Separate target architecture from the implemented package graph. Preserve arbitrary element types, operation-specific bounds, representative semantics, mutable/frozen distinctions, and specialized execution. Use actual manifest/toolchain requirements; do not infer implemented APIs from research sketches.

## Evidence and reasoning requirements

Use primary papers/specifications and versioned official documentation/source. Record URLs/DOIs, versions/revisions, access dates, relevant sections, and limitations. Map important claims to sources. Distinguish observed implementation, upstream documentation, derivation, proposal, planned experiment, executed result, and unresolved claim. Revalidate inherited parent assumptions. Never manufacture measurements, citations, proofs, or inaccessible file contents.

Specify logical domains, equivalence relations, operations, laws, counterexamples, representation invariants, ownership, order, errors, overflow, callbacks, and snapshot assumptions. Separate equality of membership from equality of observable results. Do not assume that lazy evaluation means bounded work/memory or that structural freezing establishes global consistency.

## Output by mode

**Landscape:** executive decision map, taxonomy, capability matrix, alternatives, risks, evidence gaps, dependency-ordered subtopics, and self-contained child briefs. Use `landscape-report.md`.

**Deep-dive:** formal model; law/observability matrix; algorithms and physical plans; CPU, allocation, memory and I/O bounds; Rust API sketches; representation/ownership/coherence analysis; failure/security cases; verification and benchmark design; evidence-backed recommendation and migration gates. Use `deep-dive-report.md`.

**Validation:** falsifiable claims and preconditions; independent model/control; exact environment and commands; actual results and counterexamples; confidence/coverage limits; proposed disposition. An unexecuted experiment is a plan, not a validation result.

Use useful executive-to-detail layering. As orientation, a landscape may be 2,000–4,000 words and a deep dive 4,000–8,000 words plus appendices; stop based on coverage and decision readiness, not a quota.

## Required conclusion

State the recommendation, conditions under which it changes, unresolved questions, and what implementation/measurement would distinguish remaining alternatives. Produce child handoffs where depth is insufficient and link them back to the parent. Update corpus indexes only within the authorized edit scope; report commit/push status only after verification.
