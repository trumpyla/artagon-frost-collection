---
id: REPLACE
kind: report
level: landscape
research_status: draft
implementation_status: proposed
source_validation: pending
repo_revision: UNKNOWN
created_at: ACTUAL_DATE
parent_ids: []
---

# TITLE

## Executive synthesis
Decision, main recommendation, strongest evidence, key uncertainty, and immediate next step.

## Context and current implementation
Repository revision; inspected modules/features/tests; user requirements; evidence unavailable. Distinguish implemented mechanisms from target architecture.

## Scope and non-goals
Audience, workloads, domains, constraints, and exclusions.

## Taxonomy and formal vocabulary
Define the domains before comparing operation names. Include an operation/law/observable-semantics table.

## Evidence and ecosystem map
Primary-source inventory, versioned capability matrix, conflicting sources, and what each option does not provide.

## Candidate architectures and tradeoffs
Status quo, conservative extension, specialization, and rejected alternatives. State decision criteria rather than arbitrary scores.

## Cross-cutting contracts
Representatives; ordering; ownership; errors/overflow; mutability/frozen/persistent/snapshot distinctions; concurrency; feature/coherence constraints; security boundaries.

## Prioritized research questions

| Question ID | Decision | Why existing evidence is insufficient | Dependencies | Child brief | Acceptance criteria |
| --- | --- | --- | --- | --- | --- |
| REPLACE | REPLACE | REPLACE | REPLACE | CREATE_REAL_FILE_OR_MARK_PENDING | REPLACE |

## Recommendation and roadmap
Near-term acceptance gates, deferred questions, expected owners, and conditions that would reverse the recommendation. No unapproved crate creation or API claims.

## Claim and evidence ledger

| Claim ID | Claim | Class | Source/derivation | Scope and confidence | Open validation |
| --- | --- | --- | --- | --- | --- |
| REPLACE | REPLACE | REPLACE | REPLACE | REPLACE | REPLACE |

## References
Portable references with versions, dates, sections and primary-source links. No opaque chat citation markers.

## Change/lineage record
Parent links; children; corrections; superseded claims; next review trigger.
