# Proposed root README rationale and navigation

**Editorial input, not a committed README update.** Integrate the following sections into the actual root `README.md`, preserve valid existing usage examples and installation instructions, and verify all status claims against the checkout. Links below are relative to the repository root. Add the new linked artifacts before linking them from the final README; substitute an existing canonical document where appropriate.

---

## Why Frost exists

Frost is a Rust collection library intended to provide reusable building blocks for engines that repeatedly combine facts, relationships, permissions, and symbolic state.

The goal is not a universal replacement for `Vec`, `HashMap`, or every specialized index. It is to connect **precise collection semantics, explicit ownership, and efficient physical execution**: describe what a computation means, preserve its observable contract, and exploit the capabilities of the underlying representation.

This matters in authorization engines, symbolic execution, compilers, static analysis, and query processing. Such systems often need much more than fast individual lookups. They repeatedly intersect candidates, join indexed facts, traverse relationships, preserve versions, and ask whether any result exists—sometimes without needing to construct the complete answer.

Performance is a workload-specific goal. Frost's abstractions must keep costs visible, and any claimed improvement needs measurements against relevant native or specialized alternatives.

### Mathematical foundations

Related collections do not share one universal algebra:

| Abstraction | Logical model | Important distinction |
| --- | --- | --- |
| Set | Membership in a specified domain | Union, intersection, difference; complement requires an explicit universe |
| Map | Finite partial function | Combining equal keys requires an explicit value-conflict policy |
| Bag / multiset | Finite-support multiplicity function into natural numbers | Additive sum differs from maximum-based union |
| Sequence | Ordered finite word | Concatenation preserves order and repeated occurrences |
| Multimap | A key mapped to a set, bag, or sequence of values | The per-key collection determines duplicate and ordering semantics |
| BiMap | Partial bijection | A union may violate uniqueness on either side and require rejection or resolution |

These models are useful because they identify valid transformations and reveal invalid ones. But mathematical membership equivalence is not the entire API contract. Equal Rust keys may carry different metadata. Reordering an operation can change a stored representative, output order, callback effects, overflow, or an error result. Optimization must respect the observations the API promises.

The research direction is therefore **small capabilities, domain-specific algebra, and specialized execution**, rather than one large collection interface with universal `Clone + Default + Hash + Ord` requirements.

See the [research corpus](docs/research/README.md), [foundation and engine roadmap](docs/research/synthesis/foundations-and-engine-roadmap.md), and [generic set-algebra proposal](docs/design/set-algebra.md).

### Frozen values and read-heavy execution

A motivating lifecycle is:

```text
construct or update
    -> validate and normalize
    -> freeze an appropriate representation
    -> retain or publish a version
    -> evaluate many queries
    -> materialize, consume, or rebuild explicitly when needed
```

Separating construction from evaluation can make sorting, deduplication, compression, and indexing worthwhile. Read-side execution can use borrowed traversal, sorted merging, hash probing, or encoded integer operations without forcing every representation through the same mechanism.

Several concepts must remain distinct:

| Concept | Meaning |
| --- | --- |
| Frozen collection | A collection with a defined structural immutability boundary |
| Computed set / query | A description of how to obtain membership or results from sources |
| Materialized answer | A constructed result, whose ownership and source dependencies are explicit |
| Persistent collection | A versioned representation designed to share unchanged structure |
| Snapshot | A view of data at a specified consistency/revision boundary |

A frozen value is not automatically deeply immutable, cheaply cloned, pinned, durably stored, or transactionally consistent with other values. An immutable query description does not freeze the data it references. A stable snapshot can still be too old for a particular revocation requirement.

The [Frozen API guide](docs/design/frozen-api.md) documents concrete families, exact-backend wrappers, construction and recovery operations, traversal/ownership contracts, and the boundary between existing APIs and proposals.

## Relationship to authorization and access-control research

Frost is motivated in part by research into decentralized identity, scoped delegation, capability attenuation, relationship-based authorization, and bounded authority for agent systems.

That research includes Vanadium-style blessings and caveats, Macaroons, OAuth/GNAP grants, DID and libp2p PeerId bindings, UCAN/ZCAP capabilities, credential evidence, and Kameo/libp2p actor systems. These are architectural influences and possible consumers—not protocols implemented by Frost or required dependencies of the library. Any specific protocol claim should be linked to a verified primary reference in the research corpus.

The separation of responsibility is:

```text
identity and transport authentication
    -> credential / delegation verification
    -> typed facts, scoped authority and policy revision
    -> collection algebra and query execution
    -> decision, explanation and obligations
    -> enforcement at the resource, actor or tool boundary
```

Frost belongs in the collection and computation layer. The surrounding engine must establish trust, validate proof chains, bind identities and audiences, enforce caveats, account for expiry and revocation, prevent replay, and bind a decision to the actual invocation. Authentication is not authorization; an identifier is not proof of delegated authority.

| Engine concern | Potential collection contribution | Responsibility outside Frost |
| --- | --- | --- |
| Roles and group membership | Membership sets and relationship indexes | Define inheritance, recursion and policy semantics |
| Delegation and attenuation | Constraint intersections and subset checks | Verify each delegation step and protocol-specific caveats |
| Attributes and resources | Typed maps and future joins or prefix/range indexes | Preserve attribute meaning, key normalization and permission correlations |
| Explanations | Retain IDs and representatives linking results to contributing facts | Validate, protect and interpret proof/audit evidence |
| Policy updates | Frozen versions and defined publication boundaries | Establish freshness, invalidation and cross-store consistency |
| Tool/actor execution | Fast filtering and reusable read-side state | Enforce authority, budgets, replay limits and obligations |

A deliberately simplified deny-overrides example, after all conditions have been evaluated over the same universe of complete request tuples, is:

```text
request = (principal, action, resource, context)
Effective = (Granted ∩ ScopeAllowed ∩ ContextAllowed) \ Denied
```

This is not a universal policy semantics. Flattening correlated grants into independent lists can invent permissions. Unknown values, evaluation errors, conditional grants, stale indexes, and obligations need explicit engine-level rules; they are not automatically an empty set or `false`.

### Computed sets across memory and durable storage

Zanzibar/Leopard-inspired research asks how membership and algebra can be evaluated over relationships without eagerly loading or materializing every intermediate set. The corpus should distinguish published system behavior from proposed Frost techniques and provide primary-source references.

The design space includes sorted posting streams, selective probes, bitmap kernels, durable cursors, revisioned base-plus-delta indexes, pushdown, and bounded buffering or spill. Membership, existence, pagination, exact count, and full materialization are different terminal operations and can justify different physical plans.

Lazy execution does not make arbitrary computation constant-memory or cheap. Recursive traversal, duplicate elimination, wide unions, and exact counts can still require substantial work or state. Durable snapshots, in-memory indexes, contextual facts and caches must agree on the evaluation context. These are research and integration requirements, not an implemented authorization engine.

## Symbolic execution and other applications

Symbolic engines could use collection operations for candidate states, environments, dependency graphs, constraint identifiers, and retained versions. Static analyzers could use them for worklists and facts propagated through a fixed-point algorithm. Query engines could reuse relation/key operations and posting-list intersections.

Those engines still require their own semantics: satisfiability checking, sound state merging, abstract-domain operations, termination/widening, policy interpretation, transactions, and execution control. A union of collection members does not by itself define a sound merge of symbolic program states. Partial evaluation must preserve unknown inputs rather than treating them as false.

Frost's role is to make useful low-level operations reusable and their contracts inspectable, without claiming to provide a solver, language runtime, policy engine, or identity server.

## Implementation status and architectural direction

Maintain a source-verified table here separating current facilities, proposed capabilities, and non-goals. At integration time, inspect the code rather than deriving status from research sketches.

The user-requested target is a flat `crates/frost-*` workspace with `frost-api` as the public facade and Rust library name `frost`. Until that migration is actually present, retain the current package name and installation instructions. Additional bag, multimap, BiMap, map-algebra, sequence, and index names remain proposals unless implemented.

## Documentation and project-artifact index

Resolve all destinations against the final tree. This table is intended for the actual root README, not as a replacement for the complete documentation catalog.

| Start here | Purpose | Status/category |
| --- | --- | --- |
| [Documentation index](docs/README.md) | Complete map of design, usage, reviews and maintenance artifacts | Navigation |
| [Frozen API guide](docs/design/frozen-api.md) | Frozen families, wrappers, ownership and construction/recovery contracts | Guide; mark proposals separately |
| [Design philosophy](docs/design/philosophy.md) | Stable principles and evaluation criteria | Design |
| [Architecture](docs/design/architecture.md) | Capabilities, families, profiles and boundaries | Design/current architecture |
| [Set operations](docs/set-operations.md) | Existing operation contracts and ownership | API/implementation guide |
| [General set algebra](docs/design/set-algebra.md) | Typed views and generic expression semantics | Proposal unless implemented |
| [Integer-set design](docs/design/integer-sets.md) | Encodings, representations, policies and integer execution | Design; confirm current scope |
| [Integer expressions](docs/design/integer-views.md) | Deferred execution over integer sources | Proposal unless implemented |
| [Snapshot publication](docs/design/snapshots.md) | Retained versions, publication, identity and retries | Contract/design |
| [Persistence direction](docs/design/persistent-integer-storage.md) | Structural sharing and ownership tradeoffs | Proposal/research; confirm status |
| [Research corpus](docs/research/README.md) | Surveys, summaries, detailed reports and reading paths | Research |
| [Research synthesis](docs/research/synthesis/foundations-and-engine-roadmap.md) | Decision map and prioritized follow-up questions | Synthesis, not automatic approval |
| [Source catalog](docs/research/SOURCES.md) | Primary references, provenance and evidence coverage | Research evidence |
| [Research prompt](docs/research/templates/research-prompt.md) | Launch overview, deep-dive or validation research | Template |
| [Research integration audit](docs/research/integration-audit.md) | Corrections, contradictions and missing artifacts | Review |
| [Examples](examples/) | Actual executable usage scenarios | Examples; verify applicable features |
| [Verification](docs/verification.md) | Test/model scope, assumptions and limits | Verification guide |
| [Benchmark methodology](docs/maintainers/benchmarks.md) | Workload controls and reproducibility | Measurement guide |
| [Maintainer guide](docs/maintainers/guide.md) | Development workflow and code ownership | Maintenance |
| [Contribution guide](CONTRIBUTING.md) | How to make and verify changes | Contribution |

Add crate-layout/map-index documents, dated results, public rustdoc, and Beads navigation only after locating their actual artifacts. Do not present historical validation as proof of new proposals.

**Suggested reading paths:** newcomers start with rationale → Frozen API → examples; implementers use architecture → relevant contract → tests; engine integrators use algebra → snapshots → computed-set/authorization research; researchers use corpus → synthesis → template → focused child question.
