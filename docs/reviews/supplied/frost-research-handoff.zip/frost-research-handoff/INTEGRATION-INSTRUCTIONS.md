# Frost research-corpus and README integration — agent handoff

Prepared: 2026-11-09. This is an implementation brief for a documentation task, not a completed repository change.

## 1. Your role, task, and execution defaults

You are the research editor, Rust library architect, and documentation maintainer for `trumpyla/artagon-frost-collection`.

**Make the actual repository edits. Do not finish with a proposal, a replacement README pasted only into chat, or a claim that an unavailable research job will complete later.** Integrate the supplied reports into a navigable, source-backed research corpus; establish reusable research templates; update the root `README.md` with Frost's rationale; and add a discoverable index of Frozen API design and other project artifacts.

This is a documentation/research integration change. Do not implement new collection types, create empty library crates, migrate the Cargo workspace, rename public APIs, change dependencies, or revise security semantics to make the reports appear implemented.

Execution defaults:

```yaml
repository: trumpyla/artagon-frost-collection
scope: documentation-and-research-integration
branch: docs/research-corpus-and-rationale
publication_mode: local_commit
allow_production_code_changes: false
preserve_existing_work: true
```

Use a different branch name if that name already contains unrelated work. With these defaults, create a local documentation commit if a writable checkout is available; do not push, merge, or open a PR unless the execution request authorizes it. If only a connector or read-only checkout is available, produce a complete patch/files and state that limitation. Never invent a commit, push, PR, check result, or successful file write.

The latest remote `main` observed while preparing this handoff was `1ef810fe0cb409cc9de3617a0e9ff33e7d418ddd`. That is a provenance observation, not a pin to reset the user's checkout to. Recheck your actual branch and upstream before editing. Earlier conversation claims about local commits or README updates are not evidence that those changes exist in your checkout or on GitHub.

## 2. Explicit project requirements

Preserve these user decisions while accurately distinguishing current implementation from target architecture:

- The planned public facade is **`frost-api`**, with Rust library/import name **`frost`**.
- The requested library layout is flat **`crates/frost-*`**. Do not pretend the migration is already complete.
- Generic algebra must cover arbitrary lawful element/key types, not only integers.
- Retain useful specialized execution: sorted/hash collections, integer encodings, bitmaps, lending streams, and future indexes.
- Keep mutable and frozen semantic families distinct. Do not equate structural freezing with deep immutability, persistence, or globally consistent durable storage.
- Tests, benchmarks, applicable Miri/formal verification, and crate-specific invariants should be owned with the implementation in the target architecture. Shared repository orchestration remains separate.
- Explain the connection to fast symbolic execution, authorization, policy evaluation, static analysis, and query engines as motivating workloads. Do not present those engines or performance improvements as implemented unless verified.
- Connect the work to the user's research on scoped delegation, decentralized authorization, Vanadium-style security, Macaroons, OAuth/GNAP, DID/PeerId bindings, UCAN/ZCAP, credentials, and Kameo/libp2p agent/actor systems. Treat these as research influences and possible integration boundaries, not Frost dependencies or supported protocols.
- The observed repository policy specifies Rust 1.99.1 / edition 2024 and Make-based verification. Read the current manifest, toolchain, `AGENTS.md`, `TOOLS.md`, and Makefile; do not replace them with historical report commands, an invented `xtask`, an unpinned nightly, or newly introduced Python build tooling.

## 3. Inspect the checkout before changing documentation

Record the actual repository URL, branch, HEAD, upstream, dirty paths, and toolchain. Preserve unrelated edits; never reset, force-checkout, or overwrite them.

Read `AGENTS.md`, `TOOLS.md`, `README.md`, `Cargo.toml`, `rust-toolchain.toml`, `docs/README.md`, the relevant design/maintainer guides, and existing research/template locations. Discover actual source and test paths before linking to them.

Inventory existing artifacts before creating replacements. In particular, look for:

- Frozen/family API design, architecture, and public rustdoc.
- Generic and integer set-algebra proposals, snapshot design, persistence research, and maps/indexes proposals.
- Crate-layout decisions and any actual workspace migration.
- Research templates, bibliographies, imported reports, reviews, executable models, benchmark methodology, and validation records.
- ADRs, roadmap documents, and Beads tracking if they genuinely exist.

Prefer updating a canonical artifact to creating a competing document. Do not infer file existence from conversation links, sandbox paths in reports, or prior assistant messages. A source file, accepted design document, research proposal, historical result, and task record have different authority.

## 4. Supplied inputs and completeness

The handoff bundle contains three unmodified source exports under `inputs/`. Verify them against `input-manifest.json` before importing.

| Input | Actual title / content | Integration role |
| --- | --- | --- |
| `Frost1.md.md` | Algebra and Collection Abstractions for Frost: Maps, Lists, Bags, Multimaps, and Bimaps; 920 lines | Extended collection-algebra survey and architecture proposals |
| `Frost2.md.md` | Frost Collections Research: Map, List, Bag, Multimap, and BiMap Algebra in Rust; 595 lines | Overlapping collection survey, implementation sketches, and a selected URL bibliography |
| `Frost3.md.md` | Computed Sets Research for Frost; 115 lines | Summary and delivery note referring to a separate computed-set report, template, and ZIP |

**Do not describe these as three complete, independent deep-dive reports.** The first two overlap. The third is not the full report it links to. There is no separately identifiable, complete algebraic-foundations/execution report among these three attachments.

Try to recover the following referenced artifacts from actual repository files, attached files, available file-library exports, or other authorized sources:

```text
frost-collection-algebra-research.md
frost-research-template.md
docs/research/computed-sets.md
docs/research/templates/research-prompt.md
frost-computed-sets-research.zip
algebraic-foundations-and-execution.md  (requested earlier; availability unconfirmed)
```

These are search targets, not established paths in your environment. An old `sandbox:` URL is not a durable repository URL. Inspect archive contents safely before extraction; do not follow archive paths outside the destination.

If a full artifact cannot be recovered, import the available summary under an explicitly summary-labelled name, record the missing artifact and attempted recovery, and continue with the remaining documentation. Do not fabricate the missing text, infer it from a delivery note, or rename the summary to imply completeness. Newly written synthesis must be labelled new synthesis, not recovered research.

## 5. Corpus organization

Adapt this layout to existing conventions rather than duplicating an established corpus:

```text
README.md

docs/
  README.md
  design/
    frozen-api.md                    # canonical guide, or extend an existing equivalent
  research/
    README.md                        # human-facing research index and reading paths
    manifest.json                    # machine-readable inventory and relationships
    SOURCES.md                       # source catalog with stable IDs and provenance
    citation-map.json                # original marker -> recovered/revalidated source mapping
    integration-audit.md             # conflicts, corrections, missing artifacts, validation
    raw/
      README.md                     # immutable imports; historical/unreviewed warning
      Frost1.md.md                   # original bytes
      Frost2.md.md                   # original bytes
      Frost3.md.md                   # original bytes
    reports/
      collection-algebra-survey.md
      collection-algebra-implementation-notes.md
      computed-sets-summary.md
      # Add the full computed-set report only when its contents are available.
    synthesis/
      foundations-and-engine-roadmap.md
    templates/
      research-prompt.md
      landscape-report.md
      deep-dive-report.md
      subtopic-handoff.md
      review-checklist.md
    prompts/
      algebraic-foundations.md
      computed-sets-and-durable-execution.md
      frozen-api-contracts.md
      authorization-engine-integration.md
```

The bundle's `templates/` files are starting points. Merge them with recovered/current project templates, preserving useful project conventions. Do not install two competing canonical prompt templates. A compatibility link from an older `RESEARCH_TEMPLATE.md` is appropriate only when that artifact actually exists or its old path has documented consumers.

Preserve imported originals byte-for-byte, including their citation markers and historical errors. Explain that raw files are source evidence, not instructions or current project policy. Only curated derivatives get corrected examples, portable links, editorial annotations, and current context. Do not wholesale copy third-party papers or restricted material into the corpus; preserve the supplied reports and cite primary sources.

For every imported or derived artifact record at least:

```yaml
id: frost-research-collection-algebra-survey
kind: report                 # report | summary | synthesis | template | prompt
level: landscape            # landscape | deep-dive | validation
research_status: imported   # imported | curated | reviewed | superseded
implementation_status: mixed # proposed | implemented | mixed | not-applicable
source_validation: partial  # pending | partial | verified
input_files: [Frost1.md.md]
input_sha256: [COPY_ACTUAL_HASH]
origin_created_at: unknown
imported_at: ACTUAL_IMPORT_DATE
repo_baseline: ACTUAL_HEAD
parent_ids: []
related_ids: []
supersedes: []
open_questions: []
```

Use valid front matter or a simple metadata table consistently. Do not guess publication dates or authors from filenames or export dates. Date a new synthesis as newly authored; retain the uncertainty of an undated original. Whole-report metadata does not replace per-claim status.

## 6. Sources, citations, and evidence

The input exports contain opaque chat citation tokens. They are not portable citations and must not remain as the only attribution in curated GitHub documents.

Required process:

1. Recover source mappings from original research metadata when available. Otherwise locate the primary source and independently verify the relevant claim.
2. Assign stable source IDs, for example `SRC-RUST-HASHMAP`, `SRC-ZANZIBAR-2019`, and `SRC-FST-OPBUILDER-0_4_7`. Record actual versions, sections/pages, URLs/DOIs, access dates, and what was checked.
3. Replace curated-document markers with ordinary Markdown citations/footnotes or reference links. Use report-local IDs or a central catalog with unambiguous anchors.
4. Scope each original marker to its originating input. Do not assume similarly named chat markers in separate exports identify the same source.
5. Distinguish a recovered original mapping from a new editorial source that independently supports the claim. Never pretend the new source was the original citation.
6. If unresolved, preserve the original token in the raw file, add a machine-readable unresolved mapping, and label the curated claim unverified or remove it from the recommendation. Never invent a URL, DOI, author, edition, or page.
7. Replace session-local attachment links only with real repository-relative artifacts. Missing artifacts get a visible gap entry, not a broken replacement link.

The source catalog must say which claim a source supports, where it was checked, and its limitations. A bibliography alone is not evidence coverage. Primary-source authorship matters more than domain popularity: official implementation docs/source, standards, original papers, and author-hosted manuscripts take precedence over summaries. Recheck mutable upstream documentation and release claims. Do not treat the reports' version/date/license tables as current without verification.

Use explicit claim classes: **implemented and inspected**, **documented upstream**, **derived reasoning**, **proposal**, **experiment planned**, **experiment executed**, **historical result**, and **unverified**. For a derivation, state assumptions and show enough reasoning to audit it. For a measurement, require the command, source revision, environment, workload, and retained output.

## 7. Mandatory reconciliation and technical review

Create a claim/decision matrix: topic, input locations, agreement/conflict, repository evidence, primary evidence, disposition, and follow-up. Reconcile rather than averaging conflicting recommendations.

Review these concrete hazards found in the supplied files:

| Hazard | Required disposition |
| --- | --- |
| `Frost1` proposes `frost-bags`, `frost-multimaps`, `frost-bimaps`; `Frost2` uses singular variants | Preserve alternatives; recommend one consistent naming policy as a proposal; create no crates in this task |
| `Frost1` places `try_insert(&mut self, ...)` on `FrozenBiMap` | Flag the contradiction; curated examples must place mutation on a mutable builder/family or consume/produce a new frozen value |
| `Frost1` derives `Eq`/`Hash` for a key while claiming equality ignores its `display` field | Fix the curated example with actual lawful manual implementations, or label it pseudocode; preserve the raw example |
| Proposed lookup traits accept unconstrained arbitrary `Q`, and borrowed join examples may omit necessary lifetimes/bounds | Treat as sketches; compile-check examples before labelling callable; do not add blanket bounds that destroy supported use cases |
| Different names for map capabilities and operations (`MapGet`, existing lookup traits, `difference_keys`, `difference_by_key`) | Map proposals to actual source; do not silently rename established public APIs |
| Generic sorted n-ary operations are described as total-input-linear | Verify exact upstream implementation and assumptions; parameterize source count, key comparison cost, workspace and I/O; do not transfer a documented bound to unrelated algorithms |
| Draft feature tables and CI snippets conflict with versioned feature names, default behavior, or pinned repository tooling | Keep historical proposals as proposals; do not copy them into live Cargo/CI |
| A report assumes target restrictions were unspecified | Restore the user's and current manifest's actual target constraints |
| Summary/delivery text asserts artifact creation or execution | Confirm actual files and logs; do not inherit execution claims from prose |

Also check that all operation laws specify equality, representative identity, output order, multiplicity, failure/overflow, resolver effects, and snapshots. Safe semantic traits must not become justification for unchecked memory access. `Fn` does not establish purity. A semantic law is not a proof of an arbitrary callback.

Do not merge generic sets, integer value iteration, lending FST streams, persistent data structures, and durable snapshot cursors into a fictitious universal iterator contract. Do not collapse typed integer domains or equate IDs from independently versioned dictionaries.

## 8. Produce a high-level synthesis that can drive deeper research

Create `synthesis/foundations-and-engine-roadmap.md` as a decision-oriented landscape, not a concatenation of reports. It must contain an executive map, semantic taxonomy, established facts, conflicting recommendations, major design alternatives, current-vs-planned capability matrix, prioritized questions, and an evidence-backed roadmap.

Show this lineage explicitly:

```text
question -> source -> claim -> synthesis -> focused research
         -> design/ADR proposal -> implementation task -> verification evidence
```

Research does not become an accepted design merely by being imported. Accepted design does not become implemented merely by appearing in a crate diagram. An implementation is not validated by a benchmark plan.

For each proposed subtopic give a stable question ID, parent report/section, decision to unlock, inherited assumptions to revalidate, alternatives, required primary evidence, proposed experiments, acceptance criteria, likely owning module/crate, and anticipated downstream artifacts. Keep dependent questions ordered; do not request a universal optimizer before specifying its observable semantics.

Seed at least these follow-ups:

- Algebraic foundations and observationally valid rewrites: sets, lattices, semirings/provenance where relevant, partial maps, bags, sequences, relations, and partial bijections.
- Frozen API contracts: construction, validation, ownership, thaw/extraction, borrowed/value/lending traversal, snapshots, and persistence distinctions.
- Computed sets over durable/indexed relations: Zanzibar/Leopard source audit, lazy terminals, revision-compatible indexes, overlays, external-memory plans, resource budgets and cancellation.
- Authorization and symbolic-engine integration: identity/authority boundaries, correlated permissions, partial evaluation, explanations, policy errors, revocation and consistency.
- Map merge/join planning; bag arithmetic; multimap fiber semantics; BiMap two-index integrity; prefix/rank indexes as appropriately scoped children.

The actual algebraic-foundations/execution deep dive is a gap unless a full report is recovered or separately researched. An overview may summarize verified basics but must not impersonate that missing deep dive.

## 9. Research templates: required behavior

Provide one master research prompt with `mode = landscape | deep-dive | validation`, plus report and child-handoff templates. Each must be usable without access to this conversation.

Common variables: question, decision, audience, repository/revision, inspected implementation, parent report and section, scope/non-goals, constraints, source cutoff and execution date, candidate designs, workload model, resource limits, deliverables, and stop/acceptance criteria. Unknown values must stay explicit; templates must not silently supply project facts.

A **landscape** report must produce a taxonomy, capability matrix, research gaps, decision dependencies, ranked subtopics, and ready-to-run child briefs.

A **deep-dive** report must include formal definitions and laws, counterexamples, preconditions for rewrites, API/ownership contracts, concrete algorithms, CPU/memory/I/O complexity with all relevant variables, data layouts, failure modes, alternatives, verification plans, reproducible experiments, evidence limits, and an implementation-ready recommendation.

A **validation** report must specify a falsifiable claim, a simple independent oracle/control, reproducible setup, executed/not-executed separation, counterexamples, actual results, and limits. It may conclude that a recommendation is unsupported.

A **subtopic handoff** must preserve parent question IDs and unresolved assumptions, identify why broader research is insufficient, and require feedback into the parent synthesis after the child report is reviewed. Copying a parent's claim does not independently validate it.

The attached template starters cover these requirements; adapt rather than blindly copy. Keep full technical reports readable: executive layer first, deep sections next, detailed tables/proofs/log pointers in appendices. Word ranges are guidance, not permission to pad or to omit decisive analysis.

## 10. Update the actual root README

Place the rationale near the beginning, ahead of the long API/feature catalog. Preserve valid installation instructions, examples, feature names, and existing status disclosures. Avoid a manifesto that obscures how to use the library.

Use `README-RATIONALE-DRAFT.md` as editorial input, not an unchecked replacement. The revised root README must explain:

### Why Frost

Frost's intended role is a semantics-conscious, representation-aware collection substrate for engines that repeatedly combine facts, relationships, permissions, and symbolic state. Its value proposition is reusable algebra, clear ownership, stable public abstractions, specialized kernels, and observable costs—not an unsupported claim to outperform every native collection.

### Mathematical foundations

Summarize the distinct logical domains: membership sets; finite partial maps; natural-number bag counts; ordered sequences; set/bag/list multimaps; partial bijections. Explain why operations need distinct laws and conflict policies. Connect laws to transformations only under stated observational contracts. Point to deeper research rather than attempting the whole literature review in the README.

### Frozen values and lifecycle

Explain construction/update -> validate/normalize -> freeze -> publish/retain -> evaluate -> explicitly materialize or consume/rebuild. Show the difference between:

- a value stored in an ordinary frozen collection;
- a lazy query/expression over one or more sources;
- a persistent version sharing representation;
- a read snapshot tied to a revision, including durable storage;
- a materialized answer owned independently of the query.

These are different axes. A frozen expression description alone does not freeze mutable data sources. Freezing a Rust collection does not establish deep immutability, cheap cloning, pinning, serialization compatibility, cross-store transactions, or revocation freshness. Do not invent a general `FrozenValue` type or promise every `Frozen<B>` can use a `.thaw()` method; inspect actual contracts.

### Symbolic execution and analysis

Explain candidate-state sets, symbolic environments, dependency indexes, retained versions, and terminal-specific queries as potential uses. Separate these from a language semantics, SMT solver, path-condition reasoning, abstract domain, and sound state-merging algorithm. Do not claim that arbitrary union of symbolic environments is a valid program-state merge. Partial evaluation and uncertainty are not ordinary false/absence.

### Access control and the user's broader research

Connect identity/principal binding, verified delegation and attenuation, permission/relationship evaluation, and enforcement while keeping their responsibilities distinct. Mention the relevant protocol/framework research as influences only after checking and citing any specific technical assertions.

Use a simple architecture narrative:

```text
identity / transport authentication
    -> credential and delegation verification
    -> typed facts + policy revision + request context
    -> collection algebra / query execution
    -> decision + explanation + obligations
    -> enforcement at resource, actor, or tool boundary
```

Do not conflate DID and PeerId; cryptographic binding is a separate concern. Frost does not verify proof chains or implement OAuth, GNAP, UCAN, ZCAP, Macaroons, or Vanadium merely because its data structures could serve an engine using them.

An illustrative deny-overrides formula may be shown only for fully evaluated sets over a common universe of complete request tuples `(principal, action, resource, context)`:

```text
Effective = (Granted ∩ ScopeAllowed ∩ ContextAllowed) \ Denied
```

Label it an illustration, not a universal policy semantics. Do not flatten correlated grants into independent principal/action/resource sets. Preserve unknown, error, and conditional states until an engine-specific combining rule is applied; a missing/stale/incomplete index is not proof of absence. Current proof verification, revocation, replay protection, obligations, audit policy, and check-to-use consistency remain engine responsibilities.

### Computed sets, indexes, and durable data

Present computed sets as expressions evaluated against sources at a defined revision, not necessarily resident containers. Distinguish membership, existence, bounded enumeration, exact/estimated count, and materialization. Explain that lazy execution can avoid eager result/intermediate containers but may still scan extensive data, buffer, deduplicate, traverse recursive graphs, or spill. Do not promise constant memory for arbitrary expressions, cheap exact counts, or full enumeration of infinite/wildcard universes.

Describe Zanzibar/Leopard-inspired structures, overlays, and durable cursors as research/planned integrations unless actual implementation is found. Document the requirement that index revision, durable snapshot, contextual facts, and cache semantics agree; a frozen memory index alone does not prove authorization freshness.

### Current, planned, and outside scope

Add a short status table anchored in inspected source. Preserve the planned `frost-api` / `crates/frost-*` direction without changing current package instructions. Security engines, solvers, identity servers, and distributed consistency protocols are not implied products of this documentation change.

## 11. Frozen API guide and README artifact index

Extend an existing canonical Frozen API document or create `docs/design/frozen-api.md` as an editorial guide to actual contracts plus separately marked proposals. Cover exact-backend `Frozen<B>` versus semantic families, mutable/frozen pairings, plans/builders, duplicate representatives, borrowed lookup, by-value decoding, lending cursors, extraction/thaw, errors, allocation costs, feature boundaries, auto-trait implications, and snapshot admission. Link implementation claims to actual source/test paths and feature conditions. Unsupported generalized APIs belong in a proposal section, not a usage example.

Put a curated artifact table directly in the root README. Use category, linked artifact, purpose, and status. Include routes to:

| Category | Candidate destination to inspect first |
| --- | --- |
| Complete documentation index | `docs/README.md` |
| Frozen API guide | Existing equivalent, otherwise `docs/design/frozen-api.md` |
| Principles and architecture | `docs/design/philosophy.md`, `docs/design/architecture.md`, `docs/design/decisions.md` |
| Existing set operations | `docs/set-operations.md` |
| Generic algebra proposal | `docs/design/set-algebra.md` |
| Integer sets and expression proposals | `docs/design/integer-sets.md`, `docs/design/integer-views.md` |
| Snapshot and persistence contracts | `docs/design/snapshots.md`, `docs/design/persistent-integer-storage.md` |
| Crate layout / map-index roadmap | Discover actual documents; do not assume earlier drafts were saved |
| Research corpus / synthesis / sources | New or existing `docs/research/README.md`, synthesis, and source catalog |
| Research templates and child prompts | The actual canonical template/prompt locations |
| Examples and public API | Actual examples, source modules, and verified rustdoc publication if one exists |
| Verification and benchmark methodology | `docs/verification.md`, `docs/maintainers/benchmarks.md` |
| Validation/reviews | Actual dated validation/review records, with historical scope |
| Contribution and release | Actual maintainer/contributor/release guides |
| Task tracking | Existing Beads guide or tracker, only if present |

All linked destinations must exist in the resulting tree or be verified external destinations. Use paths relative to the containing Markdown file. For an absent artifact, record a gap or create an explicitly scoped guide—never invent a clickable path. Keep the complete inventory in `docs/README.md`; the root README should orient readers rather than list every log.

Provide reading paths: new contributor; Frozen API implementer; algebra/planner implementer; authorization-engine integrator; researcher starting a subtopic. Status labels must distinguish implemented, proposal, research, historical evidence, and planned task.

## 12. Verification, tracking, and delivery

Run the checks mandated by the actual repository for this documentation change. At the observed baseline these include `make check`; consult `make help` and current `AGENTS.md` rather than copying commands for hypothetical future packages.

Validate at minimum:

- Raw-input hashes and manifest consistency.
- Every new/changed local link and heading anchor.
- JSON/YAML metadata and all populated template examples.
- Unique artifact/source/question IDs and resolvable internal references.
- Portable citations in curated files; unresolved claims explicitly recorded.
- No operational `sandbox:`/chat-library links or opaque citation tokens in curated documents. Raw originals are the narrowly documented exception; do not weaken checks globally.
- Existing README examples preserved and relevant doctests executed when tooling is available. Research pseudocode clearly labelled; compile-fail tests must not fail merely because a proposed import does not exist.
- Markdown/code-fence/Mermaid structure with an available renderer/linter; report when rendering was not performed.
- `git diff --check`, scoped diff review, and absence of unrelated source/manifest/CI changes.

Do not lower the declared toolchain to obtain a green result. Record unavailable checks as unavailable and actual failures as failures. A planned benchmark is not executed evidence. A historical successful test log does not validate this edit.

If Beads is initialized and usable, update or add research/documentation follow-ups using the actual tracker and discovered CLI; avoid duplicate tasks, fabricated IDs, or reinitialization. Track missing reports, source recovery, law audits, and scoped future design work. Do not mark unimplemented collection work complete.

Stage only intended paths. A suggested commit message is:

```text
docs: integrate research corpus and explain Frost engine foundations
```

Final delivery must name actual changed files, the new root README sections, corpus/source/template organization, corrections, unresolved artifacts/citations, checks actually run, and remaining gaps. Report branch, commit hash, and remote/PR status separately. Verify remote visibility before saying pushed. With no write access, return a ready-to-apply patch/archive and say the repository was not changed.

## Definition of done

The task is complete when the root README actually contains the rationale and navigation; all available inputs are preserved and indexed with honest completeness labels; curated research has usable citations or explicit gaps; Frozen API guidance points to real contracts; the landscape can generate focused child research; the template set is reusable without this conversation; and the final report accurately states verification and publication status.

Unavailable full reports or unrecoverable citations do not justify discarding the work, but they prevent a claim that the research corpus is complete or fully source-verified.
