# Frost research integration handoff

This archive contains instructions and drafting material for another model with repository access. It does **not** contain a completed repository patch or commit.

Give that model the complete archive and this instruction:

> Work in `trumpyla/artagon-frost-collection`. Read `INTEGRATION-INSTRUCTIONS.md` and execute the documentation integration it specifies. Verify the files under `inputs/` against `input-manifest.json`. Preserve originals, create a curated/source-backed research corpus, adapt the reusable templates, update the actual root README rationale, and add a real artifact index including Frozen API design. Treat `README-RATIONALE-DRAFT.md` as a draft to merge, not an unchecked replacement. Do not implement production APIs or claim missing reports exist. Use a dedicated documentation branch and a local commit by default; do not push unless separately authorized. Report exact edits, corrections, missing evidence, checks, commit, and publication status.

## Included material

- `INTEGRATION-INSTRUCTIONS.md`: complete task, safeguards, source handling, artifact layout and acceptance criteria.
- `README-RATIONALE-DRAFT.md`: proposed root README sections and artifact index.
- `templates/`: master research prompt, landscape report, deep-dive report, child handoff and review checklist.
- `inputs/`: three supplied, unchanged report exports.
- `input-manifest.json`: hashes, input classification and known recovery gaps.

## Important input limitations

`Frost1` and `Frost2` are overlapping collection-algebra reports. `Frost3` is a summary linking to separate files; those linked report/template/ZIP bytes are not present in this archive. Their paths are recovery targets only. Opaque exported citations require source recovery or honest unresolved status before curated publication.

The handoff also identifies concrete editorial/technical corrections, including a mutable method shown on `FrozenBiMap`, contradictory equality example code, differing crate-name proposals, and unvalidated complexity/feature/tooling assumptions.
